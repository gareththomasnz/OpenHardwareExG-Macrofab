/* util.h */
#ifndef UTIL_H
#define UTIL_H

void to_hex(char byte, char *buf);

#endif /* UTIL_H */
