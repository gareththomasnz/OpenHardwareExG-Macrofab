#!/bin/sh
./src/serial-reader.pl | src/frame-parser.pl
